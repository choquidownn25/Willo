﻿using CapaConexion.Models;
using CapaDomain.Dominio;
using System;
using System.Collections.Generic;
using System.Text;

namespace CapaService.Servicio
{
    public interface IProperty : IBaseRepository<Property>
    {
    }
}
